import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

def extract_info_from_filename(filename):
    """Extract sample name, line name, and voltages from filename."""
    basename = os.path.basename(filename)
    parts = basename.split('_')
    
    # Extract sample name (everything before first underscore)
    name = parts[0]
    
    # Extract line name (part between first and second underscore)
    line_name = parts[1]
    
    # Extract voltages
    voltage_part = filename.split('Vgs')[1].split('.txt')[0]
    voltage_gs = voltage_part.split('-ds')[0]
    voltage_ds = voltage_part.split('-ds')[1]

    # Choose reference value

    if 'R-A1g' in line_name:
        reference_value = 405  # typical value of A1g frequency (in cm-1)
    elif 'R-E2g' in line_name:
        reference_value = 380  # typical value of E2g frequency (in cm-1)
    elif 'PL' in line_name:
        reference_value = 680  # typical value of PL max wavelength (in nm)


    
    return name, line_name, voltage_gs, voltage_ds, reference_value

def process_map_data(input_file, minshift1, maxshift1):
    """
    Process map data from a .txt file, generate a histogram, heatmap, and derivative map,
    and save the results.

    Parameters:
        input_file (str): Path to the .txt file containing the map data.
        minshift1 (float): Minimum value for the derivative map color scale.
        maxshift1 (float): Maximum value for the derivative map color scale.

    Returns:
        data_values (numpy.ndarray): The 2D array of data values.
        derivative_map (numpy.ndarray): The derivative map showing the shift from the reference 
        value.
        name (str): Extracted sample name.
        line_name (str): Extracted line name.
        voltage_gs (str): Extracted gate voltage.
        voltage_ds (str): Extracted drain-source voltage.
    """
    # Extract info from filename
    name, line_name, voltage_gs, voltage_ds, reference_value = extract_info_from_filename(input_file)

    # Read the map data from the .txt file
    # Assuming the file is tab-delimited and the first row/column contains coordinates
    df = pd.read_csv(input_file, delimiter='\t', header=None)

    # Extract X and Y coordinates
    x_coords = df.iloc[0, 1:].values.astype(float)  # First row (X coordinates)
    y_coords = df.iloc[1:, 0].values.astype(float)  # First column (Y coordinates)

    # Extract the data values (excluding the first row and first column)
    data_values = df.iloc[1:, 1:].values.astype(float)

    # Flatten the data into a single row and filter out zeros
    flattened_data = data_values.flatten()
    flattened_data = flattened_data[flattened_data != 0]  # Exclude zeros

    # Define the desired range based on the line name
    if 'R-A1g' in line_name:
        range_min = 402
        range_max = 405
    elif 'R-E2g' in line_name:
        range_min = 381
        range_max = 386
    elif 'PL' in line_name:
        range_min = 660
        range_max = 695
    else:
        raise ValueError("Filename must contain 'R-A1g', 'R-E2g', or 'PL' to determine the range.")

    # Filter the data to include only values within the desired range
    filtered_data = flattened_data[(flattened_data >= range_min) & (flattened_data <= range_max)]

    # Generate a histogram of the flattened data (excluding zeros)
    plt.figure(figsize=(10, 6))
    plt.hist(filtered_data, bins=15, color='blue', edgecolor='black')
    plt.title(f'Histogram of point {name} ({line_name}), V_gs = {voltage_gs}, V_ds = {voltage_ds}')
    plt.xlabel(f'{line_name} frequency, cm-1')
    plt.ylabel('Number of points')
    plt.xlim(range_min, range_max)
    plt.grid(axis='y', alpha=0.75)

    # Save the histogram as an image
    histogram_file = f'histogram_{name}_{line_name}_Vgs{voltage_gs}_Vds{voltage_ds}.png'
    plt.savefig(histogram_file)
    plt.show()

    print(f"Histogram saved to {histogram_file}")

    # Generate a heatmap of the input data
    plt.figure(figsize=(10, 6))
    heatmap = plt.imshow(data_values, extent=[x_coords.min(), x_coords.max(), y_coords.min(), y_coords.max()],
                         aspect='auto', cmap='plasma', vmin=range_min, vmax=range_max)
    plt.colorbar(heatmap, label=f'{line_name} frequency, cm-1')
    plt.title(f'Heatmap of point {name} ({line_name}), V_gs = {voltage_gs}, V_ds = {voltage_ds}')
    plt.xlabel('X coordinate')
    plt.ylabel('Y coordinate')

    # Save the heatmap as an image
    heatmap_file = f'heatmap_{name}_{line_name}_Vgs{voltage_gs}_Vds{voltage_ds}.png'
    plt.savefig(heatmap_file)
    plt.show()

    print(f"Heatmap saved to {heatmap_file}")

    # Generate a derivative map showing the shift from the reference value
    derivative_map = data_values - reference_value

    # Plot the derivative map
    plt.figure(figsize=(10, 6))
    derivative_plot = plt.imshow(derivative_map, extent=[x_coords.min(), x_coords.max(), y_coords.min(), y_coords.max()],
                                 aspect='auto', cmap='coolwarm', vmin=minshift1, vmax=maxshift1)
    plt.colorbar(derivative_plot, label=f'Shift from {reference_value}, cm⁻¹')
    plt.title(f'Shift from {reference_value} map of point {name} ({line_name}), V_gs = {voltage_gs}, V_ds = {voltage_ds}')
    plt.xlabel('X coordinate')
    plt.ylabel('Y coordinate')

    # Save the derivative map as an image
    derivative_file = f'derivative_{name}_{line_name}_Vgs{voltage_gs}_Vds{voltage_ds}.png'
    plt.savefig(derivative_file)
    plt.show()

    print(f"Derivative map saved to {derivative_file}")

    # Filter the derivative map data to include only values within the specified range
    derivative_data = derivative_map.flatten()
    derivative_data_filtered = derivative_data[(derivative_data >= minshift1) & (derivative_data <= maxshift1)]

    # Generate a histogram of the filtered derivative map data
    plt.figure(figsize=(10, 6))
    plt.hist(derivative_data_filtered, bins=15, color='green', edgecolor='black')
    plt.title(f'Histogram of Shift from {reference_value} for point {name} ({line_name}), V_gs = {voltage_gs}, V_ds = {voltage_ds}')
    plt.xlabel(f'Shift from {reference_value}, cm⁻¹')
    plt.ylabel('Number of points')
    plt.xlim(minshift1, maxshift1)
    plt.grid(axis='y', alpha=0.75)

    # Save the histogram of the derivative map as an image
    derivative_histogram_file = f'derivative_histogram_{name}_{line_name}_Vgs{voltage_gs}_Vds{voltage_ds}.png'
    plt.savefig(derivative_histogram_file)
    plt.show()

    print(f"Derivative histogram saved to {derivative_histogram_file}")

    return data_values, derivative_map, name, line_name, voltage_gs, voltage_ds

def compare_maps(map1, map2, name1, name2, line_name1, line_name2, voltage_gs1, voltage_ds1, voltage_gs2, voltage_ds2, minshift2, maxshift2):
    """
    Compare two maps and generate a difference map or intensity ratio map.
    """
    # Case 1: Position difference (both maps contain A1g-Freq or E2g-Freq)
    if ('R-A1g-Freq' in line_name1 and 'R-A1g-Freq' in line_name2) or ('R-E2g-Freq' in line_name1 and 'R-E2g-Freq' in line_name2):
        difference_map = map1 - map2
        unit_label = 'cm⁻¹'
        map_type = 'Position Difference'

    # Case 2: Integrated intensity ratio (E2g/A1g)
    elif ('R-E2g-Area' in line_name1 and 'R-A1g-Area' in line_name2) or ('R-A1g-Area' in line_name1 and 'R-E2g-Area' in line_name2):
        difference_map = map1 / map2  # E2g/A1g intensity ratio
        unit_label = 'Intensity Ratio (E2g/A1g)'
        map_type = 'Intensity Ratio'

    # Case 3: PL wavelength difference
    elif 'PL' in line_name1 and 'PL' in line_name2:
        difference_map = map1 - map2
        unit_label = 'nm'
        map_type = 'Wavelength difference'

    else:
        raise ValueError("Invalid combination of map types.")

    # Plot the difference or ratio map
    plt.figure(figsize=(10, 6))
    difference_plot = plt.imshow(difference_map, cmap='coolwarm', vmin=minshift2, vmax=maxshift2)
    plt.colorbar(difference_plot, label=unit_label)
    plt.title(f'{map_type} Map\n{name1} ({line_name1}) vs {name2} ({line_name2})\nV_gs: {voltage_gs1} vs {voltage_gs2}, V_ds: {voltage_ds1} vs {voltage_ds2}')
    plt.xlabel('X coordinate')
    plt.ylabel('Y coordinate')

    # Save the difference or ratio map as an image
    difference_file = f'{map_type.lower().replace(" ", "_")}_{name1}_{line_name1}_Vgs{voltage_gs1}_Vds{voltage_ds1}_vs_{name2}_{line_name2}_Vgs{voltage_gs2}_Vds{voltage_ds2}.png'
    plt.savefig(difference_file)
    plt.show()

    print(f"{map_type} map saved to {difference_file}")

    # Filter the difference or ratio map data to include only values within the specified range
    difference_data = difference_map.flatten()
    difference_data_filtered = difference_data[(difference_data >= minshift2) & (difference_data <= maxshift2)]

    # Generate a histogram of the filtered difference or ratio map data
    plt.figure(figsize=(10, 6))
    plt.hist(difference_data_filtered, bins=15, color='purple', edgecolor='black')
    plt.title(f'Histogram of {map_type}\n{name1} ({line_name1}) vs {name2} ({line_name2})')
    plt.xlabel(unit_label)
    plt.ylabel('Number of points')
    plt.xlim(minshift2, maxshift2)
    plt.grid(axis='y', alpha=0.75)

    # Save the histogram of the difference or ratio map as an image
    difference_histogram_file = f'{map_type.lower().replace(" ", "_")}_histogram_{name1}_{line_name1}_Vgs{voltage_gs1}_Vds{voltage_ds1}_vs_{name2}_{line_name2}_Vgs{voltage_gs2}_Vds{voltage_ds2}.png'
    plt.savefig(difference_histogram_file)
    plt.show()

    print(f"{map_type} histogram saved to {difference_histogram_file}")

# Main function
if __name__ == "__main__":
    # Define input files
    input_files = [
        r"D:\Documents\-2025-\MoS2\map analysis\p27-1_R-A1g-Freq_Vgs0-ds0.txt",
        r"D:\Documents\-2025-\MoS2\map analysis\p27-1_R-A1g-Freq_Vgs5-ds40.txt"
    ]

    '''
    minshift and maxshift are the min-max values for the:
    (1) map of the shift from the reference position 
    (2) the difference/intensity ratio map 
    '''

    minshift1 = -5
    maxshift1 = 15
    minshift2 = 0
    maxshift2 = 20

    # Process each file and store the data values
    data_values_list = []
    file_info = []
    for input_file in input_files:
        data_values, derivative_map, name, line_name, voltage_gs, voltage_ds = process_map_data(
            input_file, minshift1, maxshift1
        )
        data_values_list.append(data_values)
        file_info.append({
            'name': name,
            'line_name': line_name,
            'voltage_gs': voltage_gs,
            'voltage_ds': voltage_ds
        })

    # Compare the two maps
    if len(data_values_list) == 2:
        compare_maps(
            data_values_list[0], data_values_list[1],
            file_info[0]['name'], file_info[1]['name'],
            file_info[0]['line_name'], file_info[1]['line_name'],
            file_info[0]['voltage_gs'], file_info[0]['voltage_ds'],
            file_info[1]['voltage_gs'], file_info[1]['voltage_ds'],
            minshift2, maxshift2
        )